package com.hrmanagmentsystem.repository;

import org.springframework.data.repository.CrudRepository;

import com.hrmanagmentsystem.bean.EmployeeDocument;

public interface EmployeeDocumentRepository extends CrudRepository<EmployeeDocument, String>{

	EmployeeDocument findByEmpId(int empId);
}
