package com.hrmanagmentsystem.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hrmanagmentsystem.bean.EmployeeDetails;
import com.hrmanagmentsystem.bean.LoginDetails;
import com.hrmanagmentsystem.repository.EmployeeRepository;
import com.hrmanagmentsystem.repository.LoginDetailsRepository;
import com.hrmanagmentsystem.services.EmployeeService;

@Component
public class EmployeeServiceImpl implements EmployeeService{

	@Autowired
	EmployeeRepository employeeRepository;

	@Autowired
	LoginDetailsRepository loginDetailsRepository;

	@Override
	public LoginDetails addEmployee(EmployeeDetails employee) {
		// TODO Auto-generated method stub
		//employee.setStatus(1);
		EmployeeDetails emp=employeeRepository.save(employee);

		LoginDetails loginDetails=new LoginDetails();
		loginDetails.setEmp_id(emp.getEmp_id());
		loginDetails.setUsername(emp.getFname().toLowerCase()+""+emp.getLname().toLowerCase());
		loginDetails.setPassword("123456");
		loginDetails.setRoll(1);
		loginDetails.setStatus(1);

		LoginDetails login=loginDetailsRepository.save(loginDetails);
		return login;
	}

	@Override
	public List<EmployeeDetails> getEmployeeList() {
		// TODO Auto-generated method stub
		List<EmployeeDetails> employeeList=employeeRepository.findAll();
		return employeeList;
	}

}
