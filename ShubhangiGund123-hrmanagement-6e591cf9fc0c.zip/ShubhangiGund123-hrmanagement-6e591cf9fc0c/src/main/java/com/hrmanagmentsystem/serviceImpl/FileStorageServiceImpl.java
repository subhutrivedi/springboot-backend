package com.hrmanagmentsystem.serviceImpl;

import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.hrmanagmentsystem.bean.EmployeeDocument;
import com.hrmanagmentsystem.bean.FileStorageProperties;
import com.hrmanagmentsystem.bean.UploadEmpDocument;
import com.hrmanagmentsystem.exception.FileStorageException;
import com.hrmanagmentsystem.exception.MyFileNotFoundException;
import com.hrmanagmentsystem.repository.EmployeeDocumentRepository;
import com.hrmanagmentsystem.services.FileStorageService;

@Component
public class FileStorageServiceImpl implements FileStorageService{

	@Autowired
	EmployeeDocumentRepository employeeDocumentRepository;
	private final Path fileStorageLocation =Paths.get("C:\\D\\HACKATHON\\uploadefiles").toAbsolutePath().normalize();
	/*
	private final Path fileStorageLocation;

	@Autowired
	public FileStorageServiceImpl(FileStorageProperties fileStorageProperties) {
		this.fileStorageLocation = Paths.get(fileStorageProperties.getUploadDir()).toAbsolutePath().normalize();

		try {
			Files.createDirectories(this.fileStorageLocation);
		} catch (Exception ex) {
			throw new FileStorageException("Could not create the directory where the uploaded files will be stored.",
					ex);
		}
	}
*/
	public String storeFile(UploadEmpDocument uploadEmpDocument) {
		// Normalize file name
		//		String fileName = uploadEmpDocument.getEmpid()+"_"+uploadEmpDocument.getDocumentType()+"_"+StringUtils.cleanPath(uploadEmpDocument.getFile().getOriginalFilename());
		String fileName = uploadEmpDocument.getEmpid()+"_"+uploadEmpDocument.getDocumentType();

		try {
			// Check if the file's name contains invalid characters
			if (fileName.contains("..")) {
				throw new FileStorageException("Sorry! Filename contains invalid path sequence " + fileName);
			}

			// Copy file to the target location (Replacing existing file with the same name)
			Path targetLocation = this.fileStorageLocation.resolve(fileName);
			Files.copy(uploadEmpDocument.getFile().getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);

			EmployeeDocument employeeDocument=employeeDocumentRepository.findByEmpId(uploadEmpDocument.getEmpid());
			if(employeeDocument!=null)
			{
				if(uploadEmpDocument.getDocumentType()==1)
				{
					employeeDocument.setAdharCard(1);
				}
				else if(uploadEmpDocument.getDocumentType()==2)
				{
					employeeDocument.setPanCard(1);
				}
				else if(uploadEmpDocument.getDocumentType()==3)
				{
					employeeDocument.setCertificate(1);
				}
				else if(uploadEmpDocument.getDocumentType()==4)
				{
					employeeDocument.setGraduationCertificate(1);
				}
				else 
				{
					employeeDocument.setOther(1);
				} 
				employeeDocumentRepository.save(employeeDocument);
			}
			else
			{
				EmployeeDocument employeeDocument1=new EmployeeDocument();		
				employeeDocument1.setEmpId(uploadEmpDocument.getEmpid());
				if(uploadEmpDocument.getDocumentType()==1)
				{
					employeeDocument1.setAdharCard(1);
				}
				else if(uploadEmpDocument.getDocumentType()==2)
				{
					employeeDocument1.setPanCard(1);
				}
				else if(uploadEmpDocument.getDocumentType()==3)
				{
					employeeDocument1.setCertificate(1);
				}
				else if(uploadEmpDocument.getDocumentType()==4)
				{
					employeeDocument1.setGraduationCertificate(1);
				}
				else 
				{
					employeeDocument1.setOther(1);
				} 
				employeeDocumentRepository.save(employeeDocument1);
			}

			return fileName;
		} catch (IOException ex) {
			throw new FileStorageException("Could not store file " + fileName + ". Please try again!", ex);
		}
	}

	public Resource loadFileAsResource(int empId, int documentType) {
		String fileName=empId+"_"+documentType;
		try {
			Path filePath = this.fileStorageLocation.resolve(fileName).normalize();
			Resource resource = new UrlResource(filePath.toUri());
			if (resource.exists()) {
				return resource;
			} else {
				throw new MyFileNotFoundException("File not found " + fileName);
			}
		} catch (MalformedURLException ex) {
			throw new MyFileNotFoundException("File not found " + fileName, ex);
		}
	}

}
