package com.hrmanagmentsystem.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class EmployeeDocument {


	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private int empId;
	private int adharCard;
	private int panCard;
	private int certificate;
	private int graduationCertificate;
	private int other;
	
	public EmployeeDocument() {}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public int getAdharCard() {
		return adharCard;
	}

	public void setAdharCard(int adharCard) {
		this.adharCard = adharCard;
	}

	public int getPanCard() {
		return panCard;
	}

	public void setPanCard(int panCard) {
		this.panCard = panCard;
	}

	public int getCertificate() {
		return certificate;
	}

	public void setCertificate(int certificate) {
		this.certificate = certificate;
	}

	public int getGraduationCertificate() {
		return graduationCertificate;
	}

	public void setGraduationCertificate(int graduationCertificate) {
		this.graduationCertificate = graduationCertificate;
	}

	public int getOther() {
		return other;
	}

	public void setOther(int other) {
		this.other = other;
	}
	
}
